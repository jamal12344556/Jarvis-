package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var reply: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        window.statusBarColor = Color.rgb(5, 11, 24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 48, 24, 24)
            setBackgroundColor(Color.rgb(5, 11, 24))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 32f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(0, 217, 255))
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "PERSONAL ASSISTANT • STANDBY"
            textSize = 12f
            setTextColor(Color.rgb(100, 190, 220))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 32)
        }
        input = EditText(this).apply {
            hint = "Scrie o comandă..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            setSingleLine(false)
            setBackgroundColor(Color.rgb(15, 30, 48))
        }
        val send = button("TRIMITE") { handle(input.text.toString()) }
        val voice = button("VORBEȘTE") { startVoice() }
        val start = button("ACTIVEAZĂ SERVICIUL") {
            val i = Intent(this, JarvisService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "JARVIS • SERVICIU ACTIV"
        }
        val stop = button("OPREȘTE SERVICIUL") {
            stopService(Intent(this, JarvisService::class.java))
            status.text = "JARVIS • STANDBY"
        }
        reply = TextView(this).apply {
            text = "Bună. Sunt JARVIS. Sistemul de bază este pregătit."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 28, 0, 0)
        }
        root.addView(title); root.addView(status)
        root.addView(input, LinearLayout.LayoutParams(-1, 120))
        root.addView(send); root.addView(voice); root.addView(start); root.addView(stop)
        root.addView(reply)
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(Color.rgb(0, 217, 255))
            setOnClickListener { action() }
        }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ro-RO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Spune-i lui JARVIS ce să facă")
        }
        try { startActivityForResult(intent, 41) }
        catch (_: Exception) { reply.text = "Recunoașterea vocală nu este disponibilă pe acest dispozitiv." }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(spoken)
            handle(spoken)
        }
    }

    private fun handle(command: String) {
        val c = command.lowercase(Locale.ROOT)
        val answer = when {
            c.contains("setări") || c.contains("settings") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); "Deschid setările telefonului."
            }
            c.contains("wifi") -> {
                startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)); "Deschid setările Wi-Fi."
            }
            c.contains("bluetooth") -> {
                startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); "Deschid setările Bluetooth."
            }
            c.contains("oră") || c.contains("ora") -> "Pot răspunde la comenzi de bază. Conectarea la un model AI necesită configurarea unui server și a unei chei API."
            command.isBlank() -> "Spune-mi ce dorești."
            else -> "Am primit: $command. Pentru răspunsuri inteligente GPT/Claude trebuie conectat un server AI cu chei API."
        }
        reply.text = answer
        if (::tts.isInitialized) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.UK
            tts.setSpeechRate(0.92f)
        }
    }
    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
