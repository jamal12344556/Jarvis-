package com.example.jarvis

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder

class JarvisService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channelId = "jarvis_status"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "JARVIS status", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_jarvis)
            .setContentTitle("JARVIS este activ")
            .setContentText("Serviciul este pornit. Deschide pentru conversație.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
