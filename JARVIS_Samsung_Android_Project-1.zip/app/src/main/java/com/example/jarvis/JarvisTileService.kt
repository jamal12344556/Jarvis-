package com.example.jarvis

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class JarvisTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }
    override fun onClick() {
        super.onClick()
        val active = qsTile.state == Tile.STATE_ACTIVE
        if (active) {
            stopService(Intent(this, JarvisService::class.java))
        } else {
            val i = Intent(this, JarvisService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        qsTile.state = if (active) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        qsTile.label = if (active) "JARVIS OFF" else "JARVIS ON"
        qsTile.updateTile()
    }
    private fun updateTile() {
        // The tile reflects the last state selected by the user.
        if (qsTile.state == Tile.STATE_UNAVAILABLE) qsTile.state = Tile.STATE_INACTIVE
        qsTile.label = if (qsTile.state == Tile.STATE_ACTIVE) "JARVIS ON" else "JARVIS OFF"
        qsTile.updateTile()
    }
}
