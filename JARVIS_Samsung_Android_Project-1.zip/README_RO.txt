JARVIS Samsung – prototip Android

CE INCLUDE
- Aplicație Android de bază cu interfață întunecată/albastră.
- Dală Quick Settings „JARVIS” pentru meniul unde apar Wi-Fi și Bluetooth.
- Pornire/oprire serviciu cu notificare persistentă.
- Recunoaștere vocală la cerere (butonul VORBEȘTE).
- Răspuns vocal Text-to-Speech.
- Câteva comenzi locale demonstrative (Setări, Wi-Fi, Bluetooth).

CE NU INCLUDE ÎNCĂ
- Cuvântul de activare permanent „Hey Jarvis”.
- Integrarea GPT/Claude. Pentru aceasta este necesar un server propriu și chei API.
- Control complet al telefonului. Android cere permisiuni explicite și unele acțiuni nu sunt permise aplicațiilor obișnuite.
- Voce identică cu cea din filme. Se folosește vocea disponibilă pe telefon, setată pe engleză UK unde este posibil.

CUM ÎL INSTALEZI
1. Deschide proiectul în Android Studio pe un calculator.
2. Așteaptă sincronizarea Gradle.
3. Conectează telefonul Samsung prin USB și activează USB debugging în Developer options.
4. Apasă Run pentru instalare.
5. Pe telefon, trage de două ori în jos panoul rapid, apasă Editare (+ / creion),
   găsește „JARVIS” și adaugă-l lângă Wi-Fi/Bluetooth.

IMPORTANT
- Acesta este cod-sursă de prototip, nu APK instalabil.
- Android poate opri servicii în fundal din motive de baterie și securitate.
- Microfonul permanent/wake word necesită un motor local de detecție, permisiuni
  suplimentare și o notificare persistentă. Nu este implementat în această versiune.
- Pentru folosire pe un telefon real, construiește cu Android Studio și testează pe dispozitiv.
